import React, { Component } from 'react';

import {Button }  from './components/Button' ;
import {Output } from './components/Output' ;
import {ClearButton} from './components/ClearButton' ;
import {Ce} from './components/Ce' ;
import {History} from './components/history' ;

import './App.css';
import * as math from 'mathjs' ;

class App extends Component {
constructor(props){
  super(props);
  this.state = {
   output: "", // Display the calculated output 
    prev: ""  // previews the history and current entries
  }
 

}


//fuction to control the operands whenever a number is clicked
handleOperand = val => {
// add the value into the preview label
this.setState({prev: this.state.prev + val}) ;

//if the last element is number then it computes the result to show in the output corner
if(!isNaN(this.state.prev.charAt(this.state.prev.length ))){

this.setState({output: math.evaluate(this.state.prev + val)})
}
}

//function to compute the equality operator
handleEqual = () =>{
  // if the current entry is a number only then
  if(!isNaN(this.state.prev)){
    // do nothing
   
  }
  
  //if the last entry is an operator and equal button is pressed then it removes the operator and computes the result 
  else if( isNaN(this.state.prev.substring(this.state.prev.length -1 ))){
    
  this.setState( {output: "" })
  this.setState({prev: math.evaluate(this.state.prev.substring(0, this.state.prev.length - 1)) })

  }
  
  // if the output is proper and valid expression then simply compute it 
  else{
    this.setState( {output: "" })
    this.setState({prev: math.evaluate(this.state.prev) })
  }
}

// CE or backspace used to delete the last entry entered into the output panell
handleCE = () =>{
 
  this.setState({
    prev: this.state.prev.substring(0, this.state.prev.length - 1)
  });
  
  
}

// handles the entry of the operators
handleOperator = val => {
  // if there is only number in the preview label then new operator is the simply added in the last
  if( !isNaN(this.state.prev)){
    
    this.setState({prev: this.state.prev + val })
    }
  // if there is an operator already as the last entry in the preview panel then this replaces or overwrites that entry with the new one entered
  else if( isNaN(this.state.prev.substring(this.state.prev.length - 1 ))){
    
    this.setState({prev: this.state.prev.substring(0, this.state.prev.length - 1) + val })
    }
   
  
   // if the last entry is a number then it computes the previous entries and places the new operator in the end
    else{ 
      this.setState({ output: math.evaluate(this.state.prev) })
       this.setState({prev: this.state.prev + val })
      
   }

  
  

}


render () {
    return (
    <div className="app">

      <div className="calc-wrapper">
      
      <br></br> <br></br>
         
        
        <History prev={this.state.prev}></History>
        <Output output={this.state.output}></Output>
        
        <div className="row">
          <ClearButton handleClear={ () => this.setState({ output : "" , prev : ""})}>AC</ClearButton>
          <Ce handleClick={ () => this.handleCE()}>CE </Ce>
          <Button handleClick={this.handleOperator}>%</ Button>
        </div>

        <div className="row">
          <Button handleClick={this.handleOperand}>7</ Button>
          <Button handleClick={this.handleOperand}>8</ Button>
          <Button handleClick={this.handleOperand}>9</ Button>
          <Button handleClick={this.handleOperator}>/</ Button>
        </div>

        <div className="row">
          <Button handleClick={this.handleOperand}>4</ Button>
          <Button handleClick={this.handleOperand}>5</ Button>
          <Button handleClick={this.handleOperand}>6</ Button>
          <Button handleClick={this.handleOperator}>*</ Button>
        </div>

        <div className="row">
          <Button handleClick={this.handleOperand}>1</ Button>
          <Button handleClick={this.handleOperand}>2</ Button>
          <Button handleClick={this.handleOperand}>3</ Button>
          <Button handleClick={this.handleOperator}>-</ Button>
        </div>

        <div className="row">
          <Button handleClick={this.handleOperand}>.</ Button>
          <Button handleClick={this.handleOperand}>0</ Button>
          <Button handleClick={() =>  this.handleEqual()}>=</ Button>
          <Button handleClick={this.handleOperator}>+</ Button>
        </div>

        

      </div>

    </div>
    )
  }

  

}

export default App;
