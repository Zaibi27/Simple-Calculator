import React from 'react' ;
import './Ce.css' ;

export const Ce = (props) => (
    <div className="CE-btn" onClick={props.handleClick}>

        {props.children}
    </div>
)