import React from 'react' 
import './history.css' ;



export const History = (props ) => (

    <div className="history">
     {props.prev}

    </div>
)