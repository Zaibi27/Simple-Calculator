import React from 'react' 
import './Output.css' ;



export const Output = (props ) => (

    <div className="output">
     {props.output}

    </div>
)
